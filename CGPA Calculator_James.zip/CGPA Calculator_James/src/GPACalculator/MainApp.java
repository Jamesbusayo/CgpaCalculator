package GPACalculator;

public class MainApp {
    public static void main(String[] args) {
        gpacalculator.runGPAProgram();
    }
}
